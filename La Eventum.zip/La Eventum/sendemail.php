<?php
$name = strip_tags(htmlspecialchars($_POST['name']));
$email_address = strip_tags(htmlspecialchars($_POST['email']));
$phone = strip_tags(htmlspecialchars($_POST['phone']));
$message = strip_tags(htmlspecialchars($_POST['message']));
   
$to = 'laeventum@gmail.com'; 
$email_subject = strip_tags(htmlspecialchars($_POST['subject']));
$email_body = "You have received a new message from your website contact form.\n"."Here are the details:\nName: $name\nEmail: $email_address\nPhone: $phone\n User Query:\n$message";
$headers = "From: user@laeventum.com" . "\r\n" . "Reply-To: $email_address"; //
if(mail($to,$email_subject,$email_body,$headers))
{
    
    echo '<script type="text/javascript">'; 
echo 'alert("Thank you! We have received your query, maximum respond time is 24-hours.");';
echo 'window.location.href = "https://laeventum.com/";';
echo '</script>';
    
}
else{
    
       echo '<script type="text/javascript">'; 
echo 'alert("Something Went Wrong, please make sure you are connected with internet.");';
echo 'window.location.href = "https://laeventum.com/contact.html";';
echo '</script>';

}
return true;
?>